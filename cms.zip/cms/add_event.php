<?php
// Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Note: Logic-ah neenga insert_event.php-la vachirundhaalum, 
// safety-ku indha file-layum logic-ah handle panna mudiyum.
// Ippo neenga form action="insert_event.php" nu kuduthurukinga.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-header bg-dark text-white text-center">
                    <h5 class="mb-0">Create New College Event</h5>
                </div>
                <div class="card-body p-4">
                    
                    <form action="insert_event.php" method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label class="form-label fw-bold">Event Name</label>
                            <input type="text" name="event_name" class="form-control" placeholder="Enter event title" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Event Date</label>
                                <input type="date" name="event_date" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Venue</label>
                                <input type="text" name="venue" class="form-control" placeholder="Room/Hall No" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Organizer Name</label>
                            <input type="text" name="organizer_name" class="form-control" placeholder="Club or Person Name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Write about the event..." required></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Event Image</label>
                            <input type="file" name="event_image" class="form-control" accept="image/*" required>
                            <small class="text-muted">Select a high-quality photo for the event banner.</small>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="add_event" class="btn btn-success">Publish Event</button>
                            <a href="index.php" class="btn btn-outline-secondary">Back to Dashboard</a>
                        </div>
                    </form>
                    </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>