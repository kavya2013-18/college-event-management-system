<?php
// 1. Session Start - User login aagi irukkaraara nu check panna idhu mukkiyam
session_start();

// 2. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// 3. Login Logic
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Admin credentials check (Database la 'admin' table irukkanum)
    $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Session settings - Admin login success!
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $username;
        
        // Success aana index.php-ku redirect pannuvom
        header("Location: index.php");
        exit();
    } else {
        $error = "Incorrect Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - College Event System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f7f6;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 400px;
        }
        .card-header {
            background: #212529;
            color: white;
            padding: 25px;
            border: none;
        }
        .btn-login {
            background: #212529;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            transition: 0.3s;
        }
        .btn-login:hover {
            background: #343a40;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 flex-column d-flex align-items-center">
            
            <div class="card login-card">
                <div class="card-header text-center">
                    <h4 class="mb-0 fw-bold">ADMIN PORTAL</h4>
                    <small class="text-secondary">Please enter your credentials</small>
                </div>
                <div class="card-body p-4">
                    
                    <?php if($error): ?>
                        <div class="alert alert-danger text-center p-2 small">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <form action="admin_login.php" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Username</label>
                            <input type="text" name="username" class="form-control form-control-lg" placeholder="e.g. admin" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Password</label>
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="••••••••" required>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="submit" name="login" class="btn btn-login fw-bold">LOGIN NOW</button>
                        </div>
                    </form>
                    
                </div>
                <div class="card-footer bg-white border-0 text-center pb-4">
                    <a href="index.php" class="text-decoration-none text-muted small">← Back to Homepage</a>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>