<?php

$conn =
mysqli_connect("localhost","root","","college_event_db",3306);

if(!$conn)
{
    die("connection failed:".mysqli_connect_error());
}

echo "connected successfully";

?>