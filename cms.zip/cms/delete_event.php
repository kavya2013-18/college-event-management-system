<?php
// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; // Unga database name-ah check pannikonga

$conn = new mysqli($host, $user, $pass, $db);

// Connection check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. URL-la irundhu ID-ya edukkurom (e.g., delete_event.php?id=5)
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // 3. SQL Delete Query
    $sql = "DELETE FROM events WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Delete aana udane alert kaatti index page-ku thirumba anupuvom
        echo "<script>
                alert('Event deleted successfully!');
                window.location.href = 'index.php';
              </script>";
    } else {
        // Error vandha message kaattum
        echo "Error deleting record: " . $conn->error;
    }
} else {
    // ID illama indha page-ku vandha index-ku redirect pannuvom
    header("Location: index.php");
}

$conn->close();
?>