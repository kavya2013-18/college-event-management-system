<?php
// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. URL-la irundhu ID-ya edukkurom (e.g., edit_event.php?id=5)
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM events WHERE id=$id");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $event_name = $row['event_name'];
        $event_date = $row['event_date'];
        $description = $row['description'];
    } else {
        echo "Event not found!";
        exit;
    }
}

// 3. Update Logic - Form submit aagum podhu
if (isset($_POST['update_event'])) {
    $id = $_POST['id'];
    $event_name  = mysqli_real_escape_string($conn, $_POST['event_name']);
    $event_date  = mysqli_real_escape_string($conn, $_POST['event_date']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "UPDATE events SET event_name='$event_name', event_date='$event_date', description='$description' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('Event updated successfully!');
                window.location.href='index.php';
              </script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Event</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow border-0">
                <div class="card-header bg-warning text-dark text-center">
                    <h4 class="mb-0">Edit Event Details</h4>
                </div>
                <div class="card-body p-4">
                    <form action="edit_event.php" method="POST">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">

                        <div class="mb-3">
                            <label class="form-label fw-bold">Event Name</label>
                            <input type="text" name="event_name" class="form-control" value="<?php echo $event_name; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Event Date</label>
                            <input type="date" name="event_date" class="form-control" value="<?php echo $event_date; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Description</label>
                            <textarea name="description" class="form-control" rows="4" required><?php echo $description; ?></textarea>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="update_event" class="btn btn-primary">Update Event</button>
                            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>