<?php
session_start();
?>

<?php
// 1. Database Connection
include("connect.php");

// 2. URL-la irundhu ID-ya edukkurom
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Updated Query: Ellaa details-um edukkurom
    $sql = "SELECT * FROM events WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<script>alert('Event not found!'); window.location.href='index.php';</script>";
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $row['event_name']; ?> - Event Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        .detail-header {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('<?php echo !empty($row['image']) ? $row['image'] : "https://via.placeholder.com/1200x400"; ?>');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 80px 0;
            margin-bottom: 30px;
        }
        .event-info-box {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-top: -100px; /* Overlap effect */
            position: relative;
            z-index: 2;
        }
        .meta-info i {
            color: #0d6efd;
            margin-right: 10px;
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">CampusEvents</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="student_events.php">Back to Home</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="detail-header text-center">
        <div class="container text-uppercase">
            <h1 class="display-4 fw-bold"><?php echo $row['event_name']; ?></h1>
            <p class="lead">Organized by: <?php echo $row['organizer_name']; ?></p>
        </div>
    </header>

    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="event-info-box">
                    <div class="row mb-4 meta-info text-center">
                        <div class="col-md-4">
                            <h5><i class="bi bi-calendar-event"></i>Date</h5>
                            <p class="text-muted"><?php echo date('F d, Y', strtotime($row['event_date'])); ?></p>
                        </div>
                        <div class="col-md-4">
                            <h5><i class="bi bi-geo-alt"></i>Venue</h5>
                            <p class="text-muted"><?php echo $row['venue']; ?></p>
                        </div>
                        <div class="col-md-4">
                            <h5><i class="bi bi-person-badge"></i>Organizer</h5>
                            <p class="text-muted"><?php echo $row['organizer_name']; ?></p>
                        </div>
                    </div>

                    <hr>

                    <h3 class="mt-4 mb-3">About this Event</h3>
                    <p style="white-space: pre-line; line-height: 1.8; font-size: 1.1rem;">
                        <?php echo $row['description']; ?>
                    </p>

                    <div class="d-grid mt-5">
                        <a href="register_event.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-lg py-3 fw-bold shadow">
                            REGISTER FOR THIS EVENT
                        </a>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-5">
                        <a href="student_events.php" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to Events</a>
                        <div>
                            <?php if(isset($_SESSION['admin'])){?>
                            <a href="student_events.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                            <button class="btn btn-sm btn-outline-secondary ms-2" onclick="window.print()">Print</button>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2026 College Event Management System. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>