<?php
include("connect.php");

// Database-la irundhu events-ah edukkurom
$sql = "SELECT * FROM events ORDER BY event_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Event Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1523580494863-6f3031224c94?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
        }
        .event-card {
            transition: transform 0.3s;
        }
        .event-card:hover {
            transform: translateY(-10px);
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">CampusEvents</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="add_event.php">Add Event</a></li>
                    <li class="nav-item"><a class="nav-link" href="student_events.php">student events</a></li>
                    <li class="nav-item"><a class="nav-link" href="view_registration.php">view registration</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold">Manage College Events Seamlessly</h1>
            <p class="lead">Register for workshops, cultural fests, and technical symposiums all in one place.</p>
            <a href="#events" class="btn btn-primary btn-lg mt-3">Explore Events</a>
        </div>
    </header>

    <section id="events" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Upcoming Events</h2>
            <div class="row g-4">
                
                <?php
                // Database-la data irundha loop panni display pannuvom
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                ?>
                    <div class="col-md-4">
                        <div class="card h-100 event-card shadow-sm">
                            <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Event">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $row['event_name']; ?></h5>
                                <p class="card-text text-muted">Date: <?php echo date('M d, Y', strtotime($row['event_date'])); ?></p>
                                <p class="card-text"><?php echo $row['description']; ?></p>
                                
                                <div class="d-flex justify-content-between">
                                    <a href="event-details.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary btn-sm">Details</a>
                                    <div>
                                        <a href="edit_event.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                        <a href="delete_event.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this event?')">Delete</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php 
                    }
                } else {
                    echo "<div class='col-12 text-center'><p class='lead'>No events found. Add one!</p></div>";
                }
                ?>

            </div>
        </div>
    </section>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p>&copy; 2026 College Event Management System. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>