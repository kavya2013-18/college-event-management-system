<?php
// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. Form submit aagi irukka nu check pannuvom
if (isset($_POST['add_event'])) {
    
    // Text data-va receive panniduvom
    $event_name     = mysqli_real_escape_string($conn, $_POST['event_name']);
    $event_date     = mysqli_real_escape_string($conn, $_POST['event_date']);
    $venue          = mysqli_real_escape_string($conn, $_POST['venue']);
    $organizer_name = mysqli_real_escape_string($conn, $_POST['organizer_name']);
    $description    = mysqli_real_escape_string($conn, $_POST['description']);

    // 3. Image Upload Logic
    $target_dir = "uploads/";
    
    // Folder illa na create pannum
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = time() . "_" . basename($_FILES["event_image"]["name"]);
    $target_file = $target_dir . $file_name;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // File-ah move pannuvom
    if (move_uploaded_file($_FILES["event_image"]["tmp_name"], $target_file)) {
        // Image success-ah upload aana dhaan SQL-la insert pannuvom
        $image_path = $target_file;

        // 4. SQL Insert Query (With all fields)
        $sql = "INSERT INTO events (event_name, event_date, description, venue, organizer_name, image) 
                VALUES ('$event_name', '$event_date', '$description', '$venue', '$organizer_name', '$image_path')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>
                    alert('Event successfully added with image!');
                    window.location.href='index.php';
                  </script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<script>
                alert('Sorry, there was an error uploading your file.');
                window.history.back();
              </script>";
    }
} else {
    header("Location: index.php");
}

$conn->close();
?>