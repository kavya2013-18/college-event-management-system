<?php
// 1. Database Connection
include("connect.php");

// 2. URL-la irundhu ID varudha nu check pannuvom
if (isset($_GET['id'])) {
    $event_id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Event details-ah fetch pannuvom (Form-la display panna)
    $event_sql = "SELECT event_name FROM events WHERE id = '$event_id'";
    $event_result = $conn->query($event_sql);
    
    if ($event_result->num_rows > 0) {
        $event_data = $event_result->fetch_assoc();
    } else {
        die("<div class='alert alert-danger'>Event not found!</div>");
    }
} else {
    header("Location: student_events.php");
    exit();
}

// 3. Form Submit Logic
if (isset($_POST['register'])) {
    $s_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $s_roll = mysqli_real_escape_string($conn, $_POST['roll_no']);
    $s_email = mysqli_real_escape_string($conn, $_POST['email']);
    $s_dept = mysqli_real_escape_string($conn, $_POST['department']);

    // MUKKIYAM: Unga phpMyAdmin-la irukka 'registration' table name-ah inga use panniruken
    $sql = "INSERT INTO registration (event_id, student_name, roll_no, email, department) 
            VALUES ('$event_id', '$s_name', '$s_roll', '$s_email', '$s_dept')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('Success! Registration completed for " . $event_data['event_name'] . "');
                window.location.href='student_events.php';
              </script>";
    } else {
        // Table name thappa irundha inga error kaattum
        echo "Database Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - <?php echo $event_data['event_name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f7f6; display: flex; align-items: center; min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .card { border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); border: none; }
        .card-header { background: #0d6efd; color: white; border-radius: 15px 15px 0 0 !important; }
        .btn-primary { padding: 12px; font-weight: bold; border-radius: 8px; }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header text-center py-4">
                    <h4 class="mb-0">Event Registration</h4>
                    <p class="mb-0 small opacity-75">Registering for: <?php echo $event_data['event_name']; ?></p>
                </div>
                <div class="card-body p-4">
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Full Name</label>
                            <input type="text" name="student_name" class="form-control" placeholder="Enter your full name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control" placeholder="Enter Roll No" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="college-id@gmail.com" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Department</label>
                            <select name="department" class="form-select" required>
                                <option value="">Select Dept</option>
                                <option value="CSE">CSE</option>
                                <option value="IT">IT</option>
                                <option value="ECE">ECE</option>
                                <option value="EEE">EEE</option>
                                <option value="MECH">MECH</option>
                            </select>
                        </div>
                        <div class="d-grid gap-2 mt-4">
                            <button type="submit" name="register" class="btn btn-primary shadow-sm">SUBMIT REGISTRATION</button>
                            <a href="student_events.php" class="btn btn-light text-muted btn-sm">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>