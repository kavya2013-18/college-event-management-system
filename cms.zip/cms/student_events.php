<?php
// 1. Database Connection
include("connect.php");

// 2. Fetch all events from database
$sql = "SELECT * FROM events ORDER BY event_date ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Events - Student Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f7f9; }
        .event-header {
            background: #0d6efd;
            color: white;
            padding: 50px 0;
            margin-bottom: 40px;
        }
        .event-card {
            border: none;
            border-radius: 12px;
            transition: 0.3s;
            overflow: hidden;
        }
        .event-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
        }
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .badge-date {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.9);
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: bold;
            color: #0d6efd;
            z-index: 1;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">CampusEvents</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                
                    <li class="nav-item"><a class="nav-link active" href="student_events.php">All Events</a></li>
        
                </ul>
            </div>
        </div>
    </nav>

    <header class="event-header text-center">
        <div class="container">
            <h1 class="display-5 fw-bold">Upcoming College Events</h1>
            <p class="lead">Register for your favorite workshops, fests, and symposiums.</p>
        </div>
    </header>

    <div class="container mb-5">
        <div class="row g-4">
            
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    // Image check
                    $img_src = !empty($row['image']) ? $row['image'] : "https://via.placeholder.com/400x250";
            ?>
                <div class="col-md-4">
                    <div class="card h-100 event-card shadow-sm position-relative">
                        <div class="badge-date shadow-sm">
                            <i class="bi bi-calendar3"></i> 
                            <?php echo date('M d', strtotime($row['event_date'])); ?>
                        </div>
                        
                        <img src="<?php echo $img_src; ?>" class="card-img-top" alt="Event Banner">
                        
                        <div class="card-body p-4">
                            <h5 class="card-title fw-bold text-dark mb-2"><?php echo $row['event_name']; ?></h5>
                            
                            <p class="text-muted mb-3 small">
                                <i class="bi bi-geo-alt-fill text-danger"></i> <?php echo $row['venue']; ?> | 
                                <i class="bi bi-person-fill text-primary"></i> <?php echo $row['organizer_name']; ?>
                            </p>
                            
                            <p class="card-text text-secondary mb-4">
                                <?php echo substr($row['description'], 0, 100) . "..."; ?>
                            </p>
                            
                            <div class="d-grid gap-2">
                                <a href="event_details.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary fw-bold">
                                    View Details
                                </a>
                                <a href="register_event.php?id=<?php echo $row['id']; ?>" class="btn btn-primary fw-bold">
                                    Register Now
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php 
                }
            } else {
                // Empty State
                echo "<div class='col-12 text-center py-5'>
                        <img src='https://cdn-icons-png.flaticon.com/512/6134/6134065.png' width='100' class='mb-3'>
                        <h3>No Events Scheduled Yet!</h3>
                        <p class='text-muted'>Check back later for new updates.</p>
                      </div>";
            }
            ?>

        </div>
    </div>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2026 College Event Management. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>