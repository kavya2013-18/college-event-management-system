<?php
session_start(); // Login session start panrom

// --- DATABASE CONNECTION ---
$servername = "localhost";
$username = "root";       
$password = "";           
$dbname = "college_event_db";
$port = 3306;  // Unga database peyarai inge maathavum

$conn = new mysqli("localhost","root","","college_event_db",3306);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// Login button click pannumpothu...
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_with_string($conn, $_POST['email']);
    $password = $_POST['password']; // Inga plain text password edukkurom

    // Student table-la email check panrom
    $sql = "SELECT id, username, password FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Password check (Registration-la password_hash use pannirundha matum password_verify use pannanum)
        // Ippo basic check-kkaga direct-ah match panrom
        if ($password == $row['password']) {
            $_SESSION['student_id'] = $row['id'];
            $_SESSION['student_name'] = $row['username'];
            
            // Login success-ana 'dashboard.php' kku pogum
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Incorrect Password!";
        }
    } else {
        $error = "No account found with this email!";
    }
}
?>

<!DOCTYPE html>
<html lang="ta">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); width: 350px; }
        h2 { text-align: center; color: #333; }
        input[type="email"], input[type="password"] { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background-color: #007bff; border: none; color: white; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #0056b3; }
        .error { color: red; font-size: 14px; text-align: center; margin-bottom: 10px; }
        .footer { text-align: center; margin-top: 15px; font-size: 14px; }
    </style>
</head>
<body>

<div class="login-card">
    <h2>Student Login</h2>
    
    <?php if($error != "") { ?>
        <div class="error"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST" action="">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="Enter your email" required>
        
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>
        
        <button type="submit">Login</button>
    </form>

    <div class="footer">
        Don't have an account? <a href="registration.php">Register here</a>
    </div>
</div>

</body>
</html>