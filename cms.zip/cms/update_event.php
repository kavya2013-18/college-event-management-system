<?php
// 1. Database Connection
$host = "localhost";
$user = "root";
$pass = "";
$db   = "college_event_db"; // Unga database name-ah confirm pannikkonga

$conn = new mysqli($host, $user, $pass, $db);

// Connection check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. Form submit aagi irukka nu check pannuvom
if (isset($_POST['update_event'])) {
    
    // Hidden field-la irundhu ID-ya edukkurom
    $id = $_POST['id'];
    
    // Form-la irundhu vara updated data
    $event_name  = mysqli_real_escape_string($conn, $_POST['event_name']);
    $event_date  = mysqli_real_escape_string($conn, $_POST['event_date']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    // 3. SQL Update Query
    // Unga table column names: event_name, event_date, description
    $sql = "UPDATE events SET 
            event_name = '$event_name', 
            event_date = '$event_date', 
            description = '$description' 
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Success aana Alert kaatti index page-ku redirect pannuvom
        echo "<script>
                alert('Event updated successfully!');
                window.location.href = 'index.php';
              </script>";
    } else {
        // Error vandha message kaattum
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Direct-ah indha page-ku vandha index-ku thiruppi anupiruvom
    header("Location: index.php");
}

$conn->close();
?>