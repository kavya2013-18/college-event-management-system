<?php
// --- DATABASE CONNECTION PART START ---
// Unga database details-ah inge kudunga
$servername = "localhost";
$username = "root";       // Unga DB username (Default "root")
$password = "";           // Unga DB password (Default empty "")
$dbname = "college_event_db";
$port = 3306;             // Unga Database peyar

// Connection create panrom
$conn = new mysqli("localhost","root","","college_event_db",3306);

// Connection check panrom (Idhu thaan error varaamal thadukkum)
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// --- DATABASE CONNECTION PART END ---

// Data-vah fetch panna query
$sql = "SELECT id, username, email, created_at FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ta">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Users View</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; background-color: #f0f2f5; }
        .container { max-width: 1000px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { text-align: center; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 15px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        tr:hover { background-color: #f1f1f1; }
        .btn { text-decoration: none; padding: 5px 10px; border-radius: 4px; font-size: 14px; }
        .btn-edit { background-color: #28a745; color: white; }
        .btn-delete { background-color: #dc3545; color: white; }
    </style>
</head>
<body>

<div class="container">
    <h2>Registered Users List</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Registration Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // $result null-ah illama irundha thaan data varum
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row["id"] . "</td>
                            <td>" . htmlspecialchars($row["username"]) . "</td>
                            <td>" . htmlspecialchars($row["email"]) . "</td>
                            <td>" . $row["created_at"] . "</td>
                            <td>
                                <a href='edit.php?id=" . $row["id"] . "' class='btn btn-edit'>Edit</a> 
                                <a href='delete.php?id=" . $row["id"] . "' class='btn btn-delete' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5' style='text-align:center;'>No records found or Table does not exist.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
// Connection-ah close panrom
$conn->close();
?>